(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.min.css
var swiper_min = __webpack_require__(722);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: external "next/dist/shared/lib/styled-jsx"
const styled_jsx_namespaceObject = require("next/dist/shared/lib/styled-jsx");
var styled_jsx_default = /*#__PURE__*/__webpack_require__.n(styled_jsx_namespaceObject);
;// CONCATENATED MODULE: ./components/_App/GoTop.js



const GoTop = ({ scrollStepInPx , delayInMs  })=>{
    const [thePosition, setThePosition] = external_react_default().useState(false);
    const timeoutRef = external_react_default().useRef(null);
    external_react_default().useEffect(()=>{
        document.addEventListener("scroll", ()=>{
            if (window.scrollY > 170) {
                setThePosition(true);
            } else {
                setThePosition(false);
            }
        });
    }, []);
    const onScrollStep = ()=>{
        if (window.pageYOffset === 0) {
            clearInterval(timeoutRef.current);
        }
        window.scroll(0, window.pageYOffset - scrollStepInPx);
    };
    const scrollToTop = ()=>{
        timeoutRef.current = setInterval(onScrollStep, delayInMs);
    };
    const renderGoTopIcon = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            /*#__PURE__*/ children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                onClick: scrollToTop,
                className: "jsx-5e588ef741f633f0" + " " + `go-top ${thePosition ? "active" : ""}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "jsx-5e588ef741f633f0" + " " + "ri-arrow-up-s-line"
                    }),
                    jsx_runtime_.jsx((styled_jsx_default()), {
                        id: "5e588ef741f633f0",
                        children: ".go-top.jsx-5e588ef741f633f0{bottom:0;z-index:4;opacity:0;right:20px;width:45px;height:45px;position:fixed;cursor:pointer;font-size:27px;text-align:center;visibility:hidden;-webkit-border-radius:50%;-moz-border-radius:50%;border-radius:50%;color:var(--whiteColor);-webkit-transition:var(--transition);-moz-transition:var(--transition);-o-transition:var(--transition);transition:var(--transition);background:var(--gradientColor);-webkit-box-shadow:0px 3px 10px rgba(0,0,0,.1);-moz-box-shadow:0px 3px 10px rgba(0,0,0,.1);box-shadow:0px 3px 10px rgba(0,0,0,.1)}.go-top.jsx-5e588ef741f633f0 i.jsx-5e588ef741f633f0{left:0;top:50%;right:0;position:absolute;text-align:center;-webkit-transform:translateY(-50%);-moz-transform:translateY(-50%);-ms-transform:translateY(-50%);-o-transform:translateY(-50%);transform:translateY(-50%);margin-left:auto;margin-right:auto}.go-top.active.jsx-5e588ef741f633f0{opacity:1;bottom:20px;visibility:visible}.go-top.jsx-5e588ef741f633f0:hover{-webkit-transform:translateY(-5px);-moz-transform:translateY(-5px);-ms-transform:translateY(-5px);-o-transform:translateY(-5px);transform:translateY(-5px)}@media only screen and (max-width:767px){.go-top.jsx-5e588ef741f633f0{right:10px;width:35px;height:35px;font-size:22px}.go-top.active.jsx-5e588ef741f633f0{bottom:10px}}@media only screen and (min-width:768px)and (max-width:991px){}@media only screen and (min-width:992px)and (max-width:1199px){}"
                    })
                ]
            })
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: renderGoTopIcon()
    });
};
/* harmony default export */ const _App_GoTop = (GoTop);

;// CONCATENATED MODULE: ./components/_App/Layout.js




const Layout = ({ children  })=>{
    // Preloader
    const [loader, setLoader] = external_react_default().useState(true);
    external_react_default().useEffect(()=>{
        setTimeout(()=>setLoader(false)
        , 1500);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "SEO Pro Marvel"
                    })
                ]
            }),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(_App_GoTop, {
                scrollStepInPx: "100",
                delayInMs: "10.50"
            })
        ]
    });
};
/* harmony default export */ const _App_Layout = (Layout);

;// CONCATENATED MODULE: ./pages/_app.js














// Global CSS


const MyApp = ({ Component , pageProps  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(_App_Layout, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
};
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 722:
/***/ (() => {



/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(227));
module.exports = __webpack_exports__;

})();